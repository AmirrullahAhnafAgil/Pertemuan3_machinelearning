import csv

# Fungsi untuk membaca data dari file CSV
def baca_csv(nama_file):
    data = []
    with open(nama_file, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append(row)
    return data

# Fungsi untuk menampilkan statistik dasar
def tampilkan_statistik(data):
    usia = [int(row['Usia']) for row in data]
    pendapatan = [int(row['Pendapatan']) for row in data]

    print("Statistik Usia:")
    print("  Rata-rata: {:.2f}".format(sum(usia) / len(usia)))
    print("  Median: {:.2f}".format(median(usia)))
    print("  Usia Minimum: {}".format(min(usia)))
    print("  Usia Maksimum: {}".format(max(usia)))

    print("\nStatistik Pendapatan:")
    print("  Rata-rata: {:.2f}".format(sum(pendapatan) / len(pendapatan)))
    print("  Median: {:.2f}".format(median(pendapatan)))
    print("  Pendapatan Minimum: {}".format(min(pendapatan)))
    print("  Pendapatan Maksimum: {}".format(max(pendapatan)))

# Fungsi untuk menghitung median
def median(data):
    sorted_data = sorted(data)
    n = len(sorted_data)
    if n % 2 == 0:
        return (sorted_data[n//2 - 1] + sorted_data[n//2]) / 2
    else:
        return sorted_data[n//2]

# Main program
def main():
    # Baca data dari file CSV
    nama_file = 'data.csv'
    data = baca_csv(nama_file)

    # Tampilkan statistik dasar
    tampilkan_statistik(data)

if __name__ == "__main__":
    main()
